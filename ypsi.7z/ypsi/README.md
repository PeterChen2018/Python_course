基于 Django + SQLite 的进销存系统
新手练习作

Screenshot：https://www.evernote.com/shard/s62/sh/79dd0941-9d2f-4d8e-8481-402591cac496/a799d5489235017d8d732f5ed0d499e4